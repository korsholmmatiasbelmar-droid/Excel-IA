# IA para Microsoft Excel — Asistente de Contabilidad (MCP)

[![MCP](https://img.shields.io/badge/MCP-Model%20Context%20Protocol-blue.svg)](https://modelcontextprotocol.io/)
[![Node](https://img.shields.io/badge/Node.js-%3E%3D18-green.svg)](https://nodejs.org/)
[![Platform](https://img.shields.io/badge/Plataforma-macOS-lightgrey.svg)](https://apple.com)

Un servidor **MCP (Model Context Protocol)** que conecta asistentes de Inteligencia Artificial (como opencode, Claude Desktop, Cursor o Antigravity) directamente con **Microsoft Excel** en tiempo real.

Diseñado especialmente para estudiantes, contadores y profesionales que necesitan resolver **ejercicios contables y financieros**: permite que la IA actúe como un copiloto al lado de tu planilla, capaz de inspeccionar datos, verificar fórmulas, registrar asientos contables (Libro Diario, Mayor, Balances) y recalcular resultados automáticamente sin salir de la conversación.

---

## Características principales

- **Control nativo y en tiempo real:** Interactúa directamente con la ventana de Excel abierta sin requerir plugins externos ni servicios en la nube.
- **Lectura y auditoría:** Inspecciona valores visibles y fórmulas subyacentes (`=SUMA`, `=BUSCARV`, etc.) para explicar qué hace una planilla o detectar errores contables.
- **Creación y apertura:** Abre planillas existentes o crea nuevos libros `.xlsx` estructurados con el nombre de hoja que elijas.
- **Escritura segura con confirmación:** Inserta tablas, filas y asientos contables completos, exigiendo siempre confirmación explícita para evitar sobreescrituras accidentales.
- **Recálculo instantáneo:** Fuerza a Excel a recalcular todas las fórmulas tras ingresar asientos o transacciones, asegurando balances cuadraos al momento.

---

## Requisitos del sistema

1. **Sistema operativo:** macOS (compatible con procesadores Apple Silicon M1/M2/M3/M4 e Intel).
2. **Aplicación:** **Microsoft Excel para Mac** instalado en `/Applications/Microsoft Excel.app`.
3. **Entorno de ejecución:** **Node.js 18 o superior** instalado en el sistema.
4. **Cliente de IA:** Cualquier aplicación compatible con el protocolo MCP (opencode, Claude Desktop, Antigravity, Cursor, etc.).
5. **Permisos de macOS:** Autorización de **Automatización** (*Ajustes del Sistema → Privacidad y seguridad → Automatización*) la primera vez que se ejecute, permitiendo controlar Microsoft Excel.

---

## Instalación paso a paso

### Paso 1: Clonar o descomprimir el proyecto
Descomprime el archivo del proyecto o ábrelo en tu terminal:
```bash
cd "IA PARA EXCEL"
```

### Paso 2: Instalar dependencias y compilar
Instala las dependencias necesarias y compila el código TypeScript a JavaScript:
```bash
npm install
npm run build
```

### Paso 3: Verificar el funcionamiento
Ejecuta la prueba de verificación para confirmar que todas las herramientas y el protocolo MCP responden correctamente:
```bash
npm test
```
*Deberás ver el mensaje `OK: 7 herramientas -> ... Prueba de humo superada`.*

---

## Cómo usarlo y conectar tu IA

### Opción A: Arranque rápido con un clic (Recomendado)
El proyecto incluye un script lanzador que abre Microsoft Excel y el asistente automáticamente:
- Haz doble clic sobre el archivo **`Abrir-microsoft-excel.command`**.
- *(Si macOS muestra un aviso de permisos, puedes abrirlo desde la terminal con: `bash Abrir-microsoft-excel.command`).*

---

### Opción B: Configuración en clientes MCP

#### 1. En **opencode**
Para registrar el MCP automáticamente en tu configuración local:
```bash
npm run configurar -- --nombre=microsoft-excel
```
O agrégalo manualmente en tu `opencode.json`:
```json
{
  "mcp": {
    "microsoft-excel": {
      "type": "local",
      "command": ["node", "./dist/index.js"],
      "enabled": true,
      "timeout": 30000
    }
  }
}
```

#### 2. En **Claude Desktop** (`claude_desktop_config.json`)
Abre tu archivo de configuración de Claude Desktop (`~/Library/Application Support/Claude/claude_desktop_config.json`) y agrega:
```json
{
  "mcpServers": {
    "microsoft-excel": {
      "command": "node",
      "args": [
        "/RUTA/ABSOLUTA/A/IA PARA EXCEL/dist/index.js"
      ]
    }
  }
}
```

#### 3. En **Antigravity CLI (agy)** o **Cursor**
Registra el servidor stdio apuntando a `dist/index.js`:
```bash
agy mcp add --type stdio microsoft-excel node "/RUTA/ABSOLUTA/A/IA PARA EXCEL/dist/index.js"
```

---

## Lista de herramientas disponibles (Tools)

El servidor expone **7 herramientas** diseñadas para cubrir el ciclo completo de trabajo en una planilla contable:

| Herramienta | Descripción | Parámetros principales | ¿Modifica datos? |
|---|---|---|:---:|
| **`listar_libros_abiertos`** | Inspecciona y devuelve todos los libros de Excel abiertos, sus rutas y los nombres exactos de sus hojas. Se usa al inicio para saber dónde trabajar. | *(Ninguno)* | **No** |
| **`leer_rango`** | Lee los valores visibles de un rango de celdas en formato A1 (ej. saldos, inventarios, cifras). | `libro`, `hoja`, `rango` (ej. `"A1:D20"`) | **No** |
| **`leer_formulas`** | Devuelve el texto exacto de las fórmulas presentes en un rango (ej. `=SUMA(C2:C10)`), ideal para auditar cálculos y balances. | `libro`, `hoja`, `rango` (ej. `"E2:E30"`) | **No** |
| **`crear_libro`** | Crea un libro de Excel en blanco en la sesión actual y, opcionalmente, lo guarda como archivo `.xlsx`. | `guardar_como` *(opcional)*, `nombre_hoja` *(opcional)* | **Sí** *(crea nuevo)* |
| **`abrir_libro`** | Abre un archivo existente en Excel (`.xlsx`, `.xlsm`, `.xls` o `.csv`) a partir de su ruta en el computador. | `ruta` *(ruta absoluta del archivo)* | **No** *(solo abre)* |
| **`escribir_rango`** | Escribe una matriz de datos o fórmulas en las celdas especificadas. Exige confirmación explícita para evitar errores de sobreescritura. | `libro`, `hoja`, `rango`, `valores` *(matriz bidimensional)*, `confirmar: true` | **Sí** *(sobrescribe)* |
| **`recalcular_libro`** | Fuerza a Excel a recalcular todas las fórmulas de todas las hojas del libro activo, asegurando cifras al día. | `libro` | **No** *(actualiza fórmulas)* |

> **Límites de seguridad:** Las operaciones de lectura y escritura están limitadas a un máximo de **5.000 celdas por llamada** para prevenir bloqueos por exceso de memoria.

---

## Ejemplos de uso con la IA

Una vez conectado el MCP a tu asistente, puedes pedirle tareas directamente en lenguaje natural:

### 1. Auditoría y revisión de un ejercicio contable
> *"Revisa el libro abierto `Balance_General.xlsx` en la hoja `Activos`. Lee el rango `A1:E25`, explícame qué cuentas están registradas y revisa si la fórmula del total de activos está sumando todas las filas correctamente."*

### 2. Estructuración de un Libro Diario desde cero
> *"Crea un libro nuevo llamado `Contabilidad_2026.xlsx` en mi Escritorio con una hoja llamada `Libro Diario`. Escribe en la primera fila los encabezados: Fecha, Código Cuenta, Glosa / Detalle, Debe y Haber, y deja el formato listo."*

### 3. Registro de asientos y cuadre de balance
> *"En el libro `Contabilidad_2026.xlsx`, hoja `Libro Diario`, ingresa el asiento de apertura con Caja al Debe por $1.500.000 y Capital al Haber por $1.500.000 en el rango `A2:E3`. Luego añade la fila de sumas totales y recalcula el libro para comprobar que cuadre."*

### 4. Detección y corrección de fórmulas
> *"Usa `leer_formulas` en la hoja `Resultados`, rango `C10:C15`. Dime qué fórmulas se usaron para calcular el Margen Operacional y si hay alguna referencia circular o error en los rangos."*

---

## Estructura del repositorio

```text
├── src/
│   ├── index.ts                 # Inicialización y servidor stdio MCP
│   ├── lib/
│   │   ├── excel.ts             # Puente nativo con Excel (AppleScript / JXA)
│   │   ├── exec.ts              # Ejecutor seguro de subprocesos
│   │   └── respuestas.ts        # Formateadores estándar de respuesta MCP
│   └── tools/
│       └── microsoft-excel.ts   # Definición, esquemas y lógica de las 7 herramientas
├── dist/                        # Código JavaScript compilado listo para ejecución
├── scripts/
│   ├── smoke-test.mjs           # Prueba de conexión y registro de herramientas
│   └── configurar-opencode.mjs  # Utilidad de registro automático en opencode
├── Abrir-microsoft-excel.command # Lanzador de un clic para macOS
├── package.json                 # Dependencias y scripts npm
└── tsconfig.json                # Configuración del compilador TypeScript
```

---

## Licencia

Distribuido bajo licencia MIT. Libre para uso educativo, profesional y personal.
