/**
 * Puente con Microsoft Excel usando AppleScript / JXA (osascript).
 *
 * Los valores que vienen del modelo se pasan SIEMPRE como argumentos de
 * osascript (`function run(argv)`), nunca se concatenan dentro del script.
 * Asi no se puede inyectar codigo AppleScript.
 */
import { existsSync } from "node:fs";
import { run, type ExecResult } from "./exec.js";

const RUTA_EXCEL_MAC = "/Applications/Microsoft Excel.app";

export type Resultado<T> =
  | { ok: true; datos: T }
  | { ok: false; error: string };

export interface LibroAbierto {
  nombre: string;
  ruta: string;
  soloLectura: boolean;
  hojas: string[];
}

export interface DatosListar {
  total: number;
  libros: LibroAbierto[];
}

export interface DatosRango {
  libro: string;
  hoja: string;
  rango: string;
  datos: unknown;
}

export interface DatosEscritura {
  libro: string;
  hoja: string;
  rango: string;
  filas: number;
  columnas: number;
}

export interface DatosLibro {
  nombre: string;
  ruta: string;
  hojas: string[];
}

export interface DatosRecalculo {
  libro: string;
  hojas: number;
  nombresHojas: string[];
}

const JXA = String.raw`
function run(argv) {
  var accion = argv[0] || "";

  function salir(datos) {
    return JSON.stringify({ ok: true, datos: datos });
  }

  function fallo(mensaje) {
    return JSON.stringify({ ok: false, error: String(mensaje) });
  }

  function mensajeDeError(e) {
    return e && e.message ? e.message : String(e);
  }

  try {
    var Excel = Application("Microsoft Excel");

    if (!Excel.running()) {
      if (accion === "abrir") {
        Excel.launch();
      } else {
        return fallo("Microsoft Excel no esta abierto. Abre Excel y vuelve a intentarlo.");
      }
    }

    function buscarLibro(nombre) {
      var libros = Excel.workbooks;
      for (var i = 0; i < libros.length; i++) {
        if (libros[i].name() === nombre) return libros[i];
      }
      var abiertos = [];
      for (var j = 0; j < libros.length; j++) {
        abiertos.push(libros[j].name());
      }
      throw new Error(
        "No hay un libro abierto llamado '" + nombre + "'. Libros abiertos: " +
        (abiertos.length ? abiertos.join(", ") : "(ninguno)") +
        ". Usa listar_libros_abiertos para ver los nombres exactos."
      );
    }

    function buscarHoja(libro, nombre) {
      var hojas = libro.worksheets;
      for (var i = 0; i < hojas.length; i++) {
        if (hojas[i].name() === nombre) return hojas[i];
      }
      var disponibles = [];
      for (var j = 0; j < hojas.length; j++) {
        disponibles.push(hojas[j].name());
      }
      throw new Error(
        "El libro '" + libro.name() + "' no tiene una hoja llamada '" + nombre +
        "'. Hojas disponibles: " + (disponibles.length ? disponibles.join(", ") : "(ninguna)") + "."
      );
    }

    if (accion === "listar") {
      var resultado = [];
      var libros = Excel.workbooks;
      for (var i = 0; i < libros.length; i++) {
        var libro = libros[i];
        var nombresHojas = [];
        try {
          nombresHojas = libro.worksheets.name();
        } catch (e) {
          nombresHojas = [];
        }
        resultado.push({
          nombre: libro.name(),
          ruta: libro.fullName(),
          soloLectura: libro.readOnly(),
          hojas: nombresHojas
        });
      }
      return salir({ total: resultado.length, libros: resultado });
    }

    if (accion === "leer" || accion === "leer_formulas") {
      var libro = buscarLibro(argv[1]);
      var hoja = buscarHoja(libro, argv[2]);
      var rango = hoja.ranges.byName(argv[3]);
      var datos = accion === "leer_formulas" ? rango.formula() : rango.value();
      return salir({
        libro: libro.name(),
        hoja: hoja.name(),
        rango: argv[3],
        datos: datos
      });
    }

    if (accion === "escribir") {
      var libro = buscarLibro(argv[1]);
      var hoja = buscarHoja(libro, argv[2]);
      var valores = JSON.parse(argv[4]);
      var rango = hoja.ranges.byName(argv[3]);
      rango.value = valores;
      return salir({
        libro: libro.name(),
        hoja: hoja.name(),
        rango: argv[3],
        filas: valores.length,
        columnas: valores.length && valores[0] ? valores[0].length : 0
      });
    }

    if (accion === "abrir") {
      var abierto = Excel.openWorkbook({ workbookFileName: argv[1] });
      return salir({
        nombre: abierto.name(),
        ruta: abierto.fullName(),
        hojas: abierto.worksheets.name()
      });
    }

    if (accion === "recalcular") {
      var libro = buscarLibro(argv[1]);
      var hojas = libro.worksheets;
      var nombres = [];
      for (var i = 0; i < hojas.length; i++) {
        var hoja = hojas[i];
        nombres.push(hoja.name());
        Excel.calculate(hoja);
      }
      return salir({ libro: libro.name(), hojas: nombres.length, nombresHojas: nombres });
    }

    return fallo("Accion interna desconocida: " + accion);
  } catch (e) {
    return fallo(mensajeDeError(e));
  }
}
`;

const APPLESCRIPT_CREAR = `on run argv
  set rutaDestino to item 1 of argv
  set nombreHoja to item 2 of argv
  tell application "Microsoft Excel"
    launch
    set nuevoLibro to make new workbook
    if nombreHoja is not "" then
      set name of worksheet 1 of nuevoLibro to nombreHoja
    end if
    if rutaDestino is not "" then
      save workbook as nuevoLibro filename rutaDestino file format Excel XML file format
    end if
    set nombreLibro to name of nuevoLibro
    set rutaLibro to full name of nuevoLibro
    set hojaInicial to name of worksheet 1 of nuevoLibro
    return nombreLibro & linefeed & rutaLibro & linefeed & hojaInicial
  end tell
end run`;

export function excelInstalado(): boolean {
  return process.platform === "darwin" && existsSync(RUTA_EXCEL_MAC);
}

function mensajeDeError(r: ExecResult): string {
  const detalle = (r.stderr || r.stdout || "").trim();
  if (!detalle) return `osascript termino con codigo ${r.code}`;
  return detalle
    .replace(/^execution error:\s*/i, "")
    .replace(/^Error:\s*/i, "")
    .trim();
}

function errorSinExcel(): Resultado<never> {
  return {
    ok: false,
    error:
      "No encuentro Microsoft Excel en /Applications. Instala Excel o muevelo a la carpeta Aplicaciones y vuelve a intentarlo.",
  };
}

async function ejecutarAccion<T>(
  accion: string,
  args: string[] = [],
  timeoutMs = 30_000,
): Promise<Resultado<T>> {
  if (!excelInstalado()) return errorSinExcel();

  const r = await run(
    "osascript",
    ["-l", "JavaScript", "-e", JXA, "--", accion, ...args],
    { timeoutMs },
  );

  const salida = (r.stdout || "").trim();
  if (!salida) {
    return { ok: false, error: mensajeDeError(r) };
  }

  try {
    const respuesta = JSON.parse(salida) as Resultado<T>;
    if (!respuesta || typeof respuesta !== "object" || typeof respuesta.ok !== "boolean") {
      return {
        ok: false,
        error: `Excel devolvio una respuesta inesperada: ${salida.slice(0, 500)}`,
      };
    }
    return respuesta;
  } catch {
    return {
      ok: false,
      error:
        mensajeDeError(r) ||
        `No pude interpretar la respuesta de Excel: ${salida.slice(0, 500)}`,
    };
  }
}

export function listarLibros(): Promise<Resultado<DatosListar>> {
  return ejecutarAccion<DatosListar>("listar");
}

export function leerRango(
  libro: string,
  hoja: string,
  rango: string,
): Promise<Resultado<DatosRango>> {
  return ejecutarAccion<DatosRango>("leer", [libro, hoja, rango]);
}

export function leerFormulas(
  libro: string,
  hoja: string,
  rango: string,
): Promise<Resultado<DatosRango>> {
  return ejecutarAccion<DatosRango>("leer_formulas", [libro, hoja, rango]);
}

export function escribirRango(
  libro: string,
  hoja: string,
  rango: string,
  valores: (string | number | boolean | null)[][],
): Promise<Resultado<DatosEscritura>> {
  return ejecutarAccion<DatosEscritura>(
    "escribir",
    [libro, hoja, rango, JSON.stringify(valores)],
    60_000,
  );
}

export function abrirLibro(ruta: string): Promise<Resultado<DatosLibro>> {
  return ejecutarAccion<DatosLibro>("abrir", [ruta], 60_000);
}

export function recalcularLibro(libro: string): Promise<Resultado<DatosRecalculo>> {
  return ejecutarAccion<DatosRecalculo>("recalcular", [libro], 60_000);
}

export async function crearLibro(
  ruta: string,
  nombreHoja: string,
): Promise<Resultado<DatosLibro>> {
  if (!excelInstalado()) return errorSinExcel();

  const r = await run(
    "osascript",
    ["-e", APPLESCRIPT_CREAR, "--", ruta, nombreHoja],
    { timeoutMs: 60_000 },
  );

  if (r.code !== 0) {
    return { ok: false, error: mensajeDeError(r) };
  }

  const lineas = (r.stdout || "").trim().split(/\r?\n/);
  const nombre = (lineas[0] || "").trim();
  const rutaFinal = (lineas[1] || "").trim();
  const hojaInicial = (lineas[2] || "").trim();

  if (!nombre) {
    return {
      ok: false,
      error: mensajeDeError(r) || "Excel no confirmo la creacion del libro.",
    };
  }

  return {
    ok: true,
    datos: {
      nombre,
      ruta: rutaFinal || ruta || nombre,
      hojas: hojaInicial ? [hojaInicial] : [],
    },
  };
}

export function normalizarRango(rango: string): string {
  return rango.replace(/\s+/g, "").toUpperCase();
}

export function esRangoA1(rango: string): boolean {
  return /^\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6}(:\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6})?$/i.test(
    normalizarRango(rango),
  );
}

function letrasANumero(letras: string): number {
  let numero = 0;
  for (const letra of letras.toUpperCase()) {
    numero = numero * 26 + (letra.charCodeAt(0) - 64);
  }
  return numero;
}

export function dimensionesRango(rango: string): { filas: number; columnas: number } {
  const limpio = normalizarRango(rango).replace(/\$/g, "");
  const partes = limpio.split(":");
  const inicio = partes[0] || "";
  const fin = partes[1] || inicio;

  const a = /^([A-Z]{1,3})([0-9]+)$/.exec(inicio);
  const b = /^([A-Z]{1,3})([0-9]+)$/.exec(fin);
  if (!a || !b) {
    throw new Error(`Rango A1 no valido: ${rango}`);
  }

  const columna1 = letrasANumero(a[1]);
  const columna2 = letrasANumero(b[1]);
  const fila1 = Number(a[2]);
  const fila2 = Number(b[2]);

  return {
    filas: Math.abs(fila2 - fila1) + 1,
    columnas: Math.abs(columna2 - columna1) + 1,
  };
}
